# src/kis_rest.py
from __future__ import annotations

import os, json, time, requests
from typing import Any, Dict, Optional, Tuple

BASE_URL = os.getenv("KIS_BASE_URL", "https://openapi.koreainvestment.com:9443")
APP_KEY = os.getenv("KOREA_INVEST_APP_KEY", "")
APP_SECRET = os.getenv("KOREA_INVEST_APP_SECRET", "")
ACC_NO = os.getenv("KOREA_INVEST_ACC_NO", "")  # 10자리(8+2) 또는 8-02 형태

TOKEN_CACHE = os.getenv("KIS_TOKEN_CACHE", r"data\token.json")

def _ensure_dir(path: str):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)

def _now() -> float:
    return time.time()

def split_account(acc: str) -> Tuple[str,str]:
    acc = (acc or "").strip()
    if "-" in acc:
        a,b = acc.split("-",1)
        return a.strip(), b.strip()
    if len(acc) >= 10:
        return acc[:8], acc[-2:]
    return acc, "01"

def _load_token() -> Optional[Dict[str, Any]]:
    try:
        with open(TOKEN_CACHE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _save_token(tok: Dict[str, Any]):
    _ensure_dir(TOKEN_CACHE)
    with open(TOKEN_CACHE, "w", encoding="utf-8") as f:
        json.dump(tok, f, ensure_ascii=False)

def get_access_token() -> str:
    cached = _load_token()
    if cached and cached.get("access_token") and cached.get("expires_at",0) - _now() > 60:
        return cached["access_token"]

    url = f"{BASE_URL}/oauth2/tokenP"
    headers = {"content-type":"application/json; charset=utf-8"}
    body = {"grant_type":"client_credentials", "appkey":APP_KEY, "appsecret":APP_SECRET}
    r = requests.post(url, headers=headers, data=json.dumps(body), timeout=10)
    r.raise_for_status()
    j = r.json()
    tok = j["access_token"]
    _save_token({"access_token": tok, "expires_at": _now()+23*3600})
    return tok

def hashkey(body: Dict[str, Any]) -> str:
    tok = get_access_token()
    url = f"{BASE_URL}/uapi/hashkey"
    headers = {
        "content-type":"application/json; charset=utf-8",
        "authorization": f"Bearer {tok}",
        "appKey": APP_KEY,
        "appSecret": APP_SECRET,
    }
    r = requests.post(url, headers=headers, data=json.dumps(body), timeout=10)
    r.raise_for_status()
    return r.json().get("HASH","")

def request(method: str, path: str, tr_id: str, params: Dict[str,Any]=None, body: Dict[str,Any]=None) -> Dict[str,Any]:
    tok = get_access_token()
    url = f"{BASE_URL}{path}"
    headers = {
        "content-type":"application/json; charset=utf-8",
        "authorization": f"Bearer {tok}",
        "appKey": APP_KEY,
        "appSecret": APP_SECRET,
        "tr_id": tr_id,
        "custtype": "P",
    }
    if body is not None:
        headers["hashkey"] = hashkey(body)

    if method.upper() == "GET":
        r = requests.get(url, headers=headers, params=params, timeout=10)
    else:
        r = requests.post(url, headers=headers, data=json.dumps(body), timeout=10)
    r.raise_for_status()
    return r.json()

def inquire_balance() -> Dict[str,Any]:
    cano, prdt = split_account(ACC_NO)
    path = "/uapi/domestic-stock/v1/trading/inquire-balance"
    tr_id = "TTTC8434R"
    params = {
        "CANO": cano,
        "ACNT_PRDT_CD": prdt,
        "AFHR_FLPR_YN": "N",
        "OFL_YN": "",
        "INQR_DVSN": "01",
        "UNPR_DVSN": "01",
        "FUND_STTL_ICLD_YN": "N",
        "FNCG_AMT_AUTO_RDPT_YN": "N",
        "PRCS_DVSN": "00",
        "CTX_AREA_FK100": "",
        "CTX_AREA_NK100": "",
    }
    return request("GET", path, tr_id, params=params)

def order_cash(side: str, symbol: str, qty: int, ord_dvsn: str="01", ord_unpr: str="0") -> Dict[str,Any]:
    cano, prdt = split_account(ACC_NO)
    path = "/uapi/domestic-stock/v1/trading/order-cash"
    tr_id = "TTTC0802U" if side.upper()=="BUY" else "TTTC0801U"
    body = {
        "CANO": cano,
        "ACNT_PRDT_CD": prdt,
        "PDNO": symbol,
        "ORD_DVSN": ord_dvsn,
        "ORD_QTY": str(int(qty)),
        "ORD_UNPR": str(ord_unpr),
        "CTAC_TLNO": "",
        "SLL_TYPE": "01",
        "ALGO_NO": "",
    }
    return request("POST", path, tr_id, body=body)

def best_effort_cash_available(balance_json: Dict[str,Any], fallback: float) -> float:
    # best-effort: 키명이 환경/버전에 따라 다를 수 있음
    candidates = [
        ("output2", 0, "dnca_tot_amt"),
        ("output2", 0, "ord_psbl_cash"),
        ("output2", 0, "tot_evlu_amt"),
    ]
    for kp in candidates:
        try:
            cur = balance_json
            for k in kp:
                cur = cur[k]
            return float(cur)
        except Exception:
            pass
    return float(fallback)
