# src/real_broker.py
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict
from kis_rest import order_cash, inquire_balance, best_effort_cash_available

@dataclass
class OrderResult:
    ok: bool
    msg: str
    raw: Dict[str,Any]

class RealBroker:
    def __init__(self):
        self.cash_fallback = float(os.getenv("START_CASH", "10000000"))

    def get_cash_available(self) -> float:
        try:
            j = inquire_balance()
            return best_effort_cash_available(j, self.cash_fallback)
        except Exception:
            return self.cash_fallback

    def buy_market(self, symbol: str, qty: int) -> OrderResult:
        j = order_cash("BUY", symbol, qty, ord_dvsn="01", ord_unpr="0")
        ok = (j.get("rt_cd") == "0")
        return OrderResult(ok, j.get("msg1",""), j)

    def sell_market(self, symbol: str, qty: int) -> OrderResult:
        j = order_cash("SELL", symbol, qty, ord_dvsn="01", ord_unpr="0")
        ok = (j.get("rt_cd") == "0")
        return OrderResult(ok, j.get("msg1",""), j)
