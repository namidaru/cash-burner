# src/engine.py
from __future__ import annotations

import os, time, math
from dataclasses import dataclass
from collections import defaultdict, deque
from typing import Dict, Deque, Tuple

from real_broker import RealBroker

def _f(x, d=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return d

def _ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")

def _ensure_dir_for_file(path: str):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)

@dataclass
class Position:
    symbol: str
    qty: int = 0
    entry_price: float = 0.0
    entry_ts: float = 0.0
    max_price: float = 0.0
    armed_trail: bool = False
    def is_open(self) -> bool:
        return self.qty > 0

class Engine:
    """REAL trading engine (minimal):
    - Signal: 10s surge + orderbook confirm
    - Size: cash_available * 30%
    - Exit: hard stop -3.5%, trail arms at +4% and trails by 3.5%
    """
    def __init__(self):
        self.window_sec = int(os.getenv("WINDOW_SEC","10"))

        self.min_ret_pct = float(os.getenv("MIN_RET_PCT","0.6"))
        self.min_tr_value = float(os.getenv("MIN_TR_VALUE","0"))
        self.min_tick_count = int(os.getenv("MIN_TICK_COUNT","5"))
        self.min_imb = float(os.getenv("MIN_IMB","0.60"))
        self.max_spread_pct = float(os.getenv("MAX_SPREAD_PCT","0.30"))

        self.position_pct = float(os.getenv("POSITION_PCT","0.30"))

        self.hard_stop_pct = float(os.getenv("HARD_STOP_PCT","3.5"))
        self.trail_arm_profit_pct = float(os.getenv("TRAIL_ARM_PCT","4.0"))
        self.trail_drop_pct = float(os.getenv("TRAIL_DROP_PCT","3.5"))

        self.kill_switch_file = os.getenv("KILL_SWITCH_FILE", r"data\\kill.switch")
        self.ledger_file = os.getenv("LEDGER_FILE", r"data\\ledger_real.csv")

        self.book: Dict[str, Dict[str,str]] = {}
        self.ticks: Dict[str, Deque[Tuple[float,float,float]]] = defaultdict(lambda: deque(maxlen=5000))
        self.pos: Dict[str, Position] = {}

        self.real = RealBroker()
        self._init_files()

    def _init_files(self):
        _ensure_dir_for_file(self.ledger_file)
        if not os.path.exists(self.ledger_file):
            with open(self.ledger_file, "w", encoding="utf-8") as f:
                f.write("ts,action,symbol,qty,price,reason,ok,msg\n")

    def _kill_active(self) -> bool:
        try:
            return os.path.exists(self.kill_switch_file)
        except Exception:
            return False

    def _log(self, ts_epoch: float, action: str, symbol: str, qty: int, price: float, reason: str, ok: bool, msg: str):
        safe = (msg or "").replace('"','')[:200]
        with open(self.ledger_file, "a", encoding="utf-8") as f:
            f.write(f"{ts_epoch:.3f},{action},{symbol},{qty},{price:.4f},\"{reason}\",{1 if ok else 0},\"{safe}\"\n")

    def on_orderbook(self, row: Dict[str,str], ts_epoch: float):
        sym = row.get("MKSC_SHRN_ISCD","")
        if sym:
            self.book[sym] = row

    def _maybe_exit(self, sym: str, price: float, ts_epoch: float):
        p = self.pos.get(sym)
        if not p or not p.is_open():
            return

        if price > p.max_price:
            p.max_price = price
        if (not p.armed_trail) and price >= p.entry_price * (1.0 + self.trail_arm_profit_pct/100.0):
            p.armed_trail = True

        if price <= p.entry_price * (1.0 - self.hard_stop_pct/100.0):
            rr = self.real.sell_market(sym, p.qty)
            self._log(ts_epoch, "SELL", sym, p.qty, price, f"hard_stop {self.hard_stop_pct}%", rr.ok, rr.msg)
            if rr.ok:
                p.qty = 0
            return

        if p.armed_trail:
            trail_stop = p.max_price * (1.0 - self.trail_drop_pct/100.0)
            if price <= trail_stop:
                rr = self.real.sell_market(sym, p.qty)
                self._log(ts_epoch, "SELL", sym, p.qty, price, f"trail_stop drop={self.trail_drop_pct}%", rr.ok, rr.msg)
                if rr.ok:
                    p.qty = 0
                return

    def on_trade(self, row: Dict[str,str], ts_epoch: float):
        if self._kill_active():
            return

        sym = row.get("MKSC_SHRN_ISCD","")
        if not sym:
            return
        price = _f(row.get("STCK_PRPR"))
        vol = _f(row.get("CNTG_VOL"))
        if price <= 0:
            return

        self._maybe_exit(sym, price, ts_epoch)

        dq = self.ticks[sym]
        dq.append((ts_epoch, price, vol))
        while dq and ts_epoch - dq[0][0] > self.window_sec:
            dq.popleft()
        if len(dq) < 2:
            return

        base = dq[0][1]
        ret = (price - base)/base*100.0
        trv = sum(p*v for _,p,v in dq)
        tick_count = len(dq)

        if ret < self.min_ret_pct:
            return
        if trv < self.min_tr_value:
            return
        if tick_count < self.min_tick_count:
            return

        ob = self.book.get(sym)
        if not ob:
            return

        bid_tot = _f(ob.get("TOTAL_BIDP_RSQN"))
        ask_tot = _f(ob.get("TOTAL_ASKP_RSQN"))
        denom = bid_tot + ask_tot
        imb = (bid_tot/denom) if denom>0 else 0.5

        ask1 = _f(ob.get("ASKP1"))
        bid1 = _f(ob.get("BIDP1"))
        mid = (ask1+bid1)/2 if (ask1>0 and bid1>0) else price
        spread = ((ask1-bid1)/mid*100.0) if mid>0 else 999

        if imb < self.min_imb or spread > self.max_spread_pct:
            return

        p = self.pos.get(sym)
        if p and p.is_open():
            return

        cash = self.real.get_cash_available()
        target = cash * self.position_pct
        qty = int(math.floor(target / price))
        if qty <= 0:
            return

        rr = self.real.buy_market(sym, qty)
        self._log(ts_epoch, "BUY", sym, qty, price, f"signal ret={ret:.2f}% imb={imb:.2f} spr={spread:.2f}%", rr.ok, rr.msg)
        if rr.ok:
            self.pos[sym] = Position(symbol=sym, qty=qty, entry_price=price, entry_ts=ts_epoch, max_price=price, armed_trail=False)
