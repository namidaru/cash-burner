# src/ws_capture.py
import os
import json
import time
import sys
import queue
import threading
import requests
import websocket

sys.path.insert(0, os.path.dirname(__file__))

APP_KEY = os.getenv("KOREA_INVEST_APP_KEY", "")
APP_SECRET = os.getenv("KOREA_INVEST_APP_SECRET", "")
MODE = os.getenv("MODE", "real").lower()  # real | demo

SYMBOLS = [s.strip() for s in os.getenv("SYMBOLS", "005930").split(",") if s.strip()]
TR_IDS = [t.strip() for t in os.getenv("TR_IDS", "H0STCNT0,H0STASP0").split(",") if t.strip()]

OUT_FILE = os.getenv("OUT_FILE", r"..\data\ws_dump.log")
CONTROL_FILE = os.getenv("CONTROL_FILE", r"..\data\ws_control.log")  # JSON 응답/에러 기록

STOP_AFTER_FIRST_DATA = os.getenv("STOP_AFTER_FIRST_DATA", "0") == "1"

# reconnect/backoff
RECONNECT = os.getenv("RECONNECT", "1") == "1"
BACKOFF_MIN = float(os.getenv("BACKOFF_MIN", "1.0"))
BACKOFF_MAX = float(os.getenv("BACKOFF_MAX", "15.0"))

# capture I/O buffering
FLUSH_INTERVAL_SEC = float(os.getenv("FLUSH_INTERVAL_SEC", "0.2"))
QUEUE_MAX = int(os.getenv("CAPTURE_QUEUE_MAX", "50000"))  # 너무 크면 메모리, 너무 작으면 drop
DROP_POLICY = os.getenv("DROP_POLICY", "drop_new").lower()  # drop_new | drop_old

# health logging
HEALTH_LOG_SEC = float(os.getenv("HEALTH_LOG_SEC", "60"))

WS_URL = "ws://ops.koreainvestment.com:21000"
REST_BASE_REAL = "https://openapi.koreainvestment.com:9443"
REST_BASE_DEMO = "https://openapivts.koreainvestment.com:29443"


def rest_base() -> str:
    return REST_BASE_DEMO if MODE == "demo" else REST_BASE_REAL


def ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _ensure_dir(path: str):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


def _append_control(msg: str):
    _ensure_dir(CONTROL_FILE)
    with open(CONTROL_FILE, "a", encoding="utf-8") as f:
        f.write(f"{ts()}\t{msg}\n")


def validate_env():
    miss = []
    if not APP_KEY:
        miss.append("KOREA_INVEST_APP_KEY")
    if not APP_SECRET:
        miss.append("KOREA_INVEST_APP_SECRET")
    if not SYMBOLS:
        miss.append("SYMBOLS")
    if miss:
        raise SystemExit("필수 환경변수 누락: " + ", ".join(miss))


def get_approval_key() -> str:
    url = f"{rest_base()}/oauth2/Approval"
    headers = {"content-type": "application/json; charset=utf-8"}
    body = {"grant_type": "client_credentials", "appkey": APP_KEY, "secretkey": APP_SECRET}
    r = requests.post(url, headers=headers, data=json.dumps(body), timeout=10)
    r.raise_for_status()
    return r.json()["approval_key"]


def build_subscribe_msg(approval_key: str, tr_id: str, code: str, tr_type: str = "1") -> str:
    return json.dumps({
        "header": {"approval_key": approval_key, "custtype": "P", "tr_type": tr_type, "content-type": "utf-8"},
        "body": {"input": {"tr_id": tr_id, "tr_key": code}}
    })


def is_data_message(s: str) -> bool:
    return isinstance(s, str) and (s.startswith("0|") or s.startswith("1|"))


class BufferedWriter:
    def __init__(self, out_path: str):
        self.out_path = out_path
        self.q = queue.Queue(maxsize=QUEUE_MAX)
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)

        self.total_in = 0
        self.total_written = 0
        self.total_dropped = 0

    def start(self):
        _ensure_dir(self.out_path)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        self.thread.join(timeout=5)

    def put_line(self, line: str):
        self.total_in += 1
        try:
            self.q.put_nowait(line)
        except queue.Full:
            # drop policy
            self.total_dropped += 1
            if DROP_POLICY == "drop_old":
                try:
                    _ = self.q.get_nowait()
                    self.q.put_nowait(line)
                except Exception:
                    pass
            # drop_new이면 그냥 버림

    def _run(self):
        # 라인 버퍼링: 한 번 열고 계속 append (flush 주기)
        f = open(self.out_path, "a", encoding="utf-8", buffering=1)
        last_flush = time.time()
        buf = []

        try:
            while not self.stop_event.is_set():
                # queue drain
                try:
                    item = self.q.get(timeout=0.05)
                    buf.append(item)
                except queue.Empty:
                    pass

                now = time.time()
                if buf and (now - last_flush >= FLUSH_INTERVAL_SEC):
                    f.write("\n".join(buf) + "\n")
                    self.total_written += len(buf)
                    buf.clear()
                    last_flush = now

            # final flush
            # drain remaining quickly
            while True:
                try:
                    buf.append(self.q.get_nowait())
                except queue.Empty:
                    break
            if buf:
                f.write("\n".join(buf) + "\n")
                self.total_written += len(buf)
                buf.clear()
        finally:
            try:
                f.flush()
                f.close()
            except Exception:
                pass


def run_once():
    writer = BufferedWriter(OUT_FILE)
    writer.start()

    # header
    writer.put_line(f"# ---- session start {ts()} mode={MODE} tr_ids={TR_IDS} symbols={SYMBOLS} ----")

    stats = {
        "json_msgs": 0,
        "data_msgs": 0,
        "last_data_ts": 0.0,
        "last_health_ts": time.time(),
    }

    def on_open(ws):
        print(ts(), "[OPEN]", WS_URL, "mode=", MODE)
        ak = get_approval_key()
        print(ts(), "[APPROVAL] ok len=", len(ak), "base=", rest_base())

        for code in SYMBOLS:
            for tr in TR_IDS:
                ws.send(build_subscribe_msg(ak, tr, code, "1"))

        print(ts(), "[SUB] sent tr_ids=", TR_IDS, "symbols=", SYMBOLS)
        print(ts(), "[DUMP] ->", OUT_FILE, "stop_after_first=", STOP_AFTER_FIRST_DATA)

    def on_message(ws, message):
        s = message if isinstance(message, str) else message.decode("utf-8", errors="ignore")

        # keepalive
        if s == "PINGPONG":
            try:
                ws.send("PINGPONG")
            except Exception:
                pass
            return

        # JSON 응답은 control log로만 남김 (운영상 원인 추적)
        if s.startswith("{"):
            stats["json_msgs"] += 1
            # 너무 길면 잘라 기록
            _append_control(s[:2000])
            return

        if not is_data_message(s):
            return

        stats["data_msgs"] += 1
        stats["last_data_ts"] = time.time()
        writer.put_line(f"{ts()}\t{s}")

        # health log
        now = time.time()
        if now - stats["last_health_ts"] >= HEALTH_LOG_SEC:
            stats["last_health_ts"] = now
            print(ts(), f"[HEALTH] data={stats['data_msgs']} json={stats['json_msgs']} "
                        f"queued={writer.q.qsize()} dropped={writer.total_dropped}")

        if STOP_AFTER_FIRST_DATA:
            print(ts(), "[STOP] first data saved -> closing")
            ws.close()

    def on_error(ws, err):
        print(ts(), "[ERR]", err)
        _append_control(f"ERR {err}")

    def on_close(ws, code, msg):
        print(ts(), "[CLOSE] code=", code, "msg=", msg)
        _append_control(f"CLOSE code={code} msg={msg}")

    ws = websocket.WebSocketApp(
        WS_URL,
        on_open=on_open,
        on_message=on_message,
        on_error=on_error,
        on_close=on_close,
    )
    ws.run_forever(ping_interval=30, ping_timeout=10)

    # stop writer (flush remaining)
    writer.stop()


def main():
    validate_env()
    backoff = BACKOFF_MIN

    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            print(ts(), "[EXIT] keyboard interrupt")
            return
        except Exception as e:
            print(ts(), f"[CRASH] {e}")
            _append_control(f"CRASH {e}")

        if not RECONNECT:
            return

        print(ts(), f"[RECONNECT] sleeping {backoff:.1f}s then reconnect")
        time.sleep(backoff)
        backoff = min(BACKOFF_MAX, backoff * 2)


if __name__ == "__main__":
    main()
