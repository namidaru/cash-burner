# src/runner.py
from __future__ import annotations

import os, time, sys
sys.path.insert(0, os.path.dirname(__file__))

from parser import extract_raw, parse_ws_raw_multi
from engine import Engine

def parse_prefix_ts(line: str) -> float:
    if "\t" not in line:
        return time.time()
    prefix = line.split("\t",1)[0].strip()
    try:
        st = time.strptime(prefix, "%Y-%m-%d %H:%M:%S")
        return time.mktime(st)
    except Exception:
        return time.time()

def process_line(engine: Engine, line: str):
    line = line.rstrip("\n")
    if not line or line.startswith("#"):
        return
    ts_epoch = parse_prefix_ts(line)
    raw = extract_raw(line)
    events = parse_ws_raw_multi(raw)
    for tr_id, row in events:
        vlen = int(row.get("_values_len","0"))
        clen = int(row.get("_cols_len","0"))
        if vlen != clen:
            continue
        if tr_id == "H0STASP0":
            engine.on_orderbook(row, ts_epoch)
        else:
            engine.on_trade(row, ts_epoch)

def run_live(path: str, poll: float = 0.2):
    eng = Engine()
    while True:
        try:
            with open(path, "r", encoding="utf-8") as f:
                f.seek(0,2)
                print(time.strftime("%Y-%m-%d %H:%M:%S"), f"[LIVE] {path}")
                while True:
                    line = f.readline()
                    if line:
                        process_line(eng, line)
                    else:
                        time.sleep(poll)
        except FileNotFoundError:
            time.sleep(1)

if __name__ == "__main__":
    in_file = os.getenv("IN_FILE", r"data\ws_dump.log")
    poll = float(os.getenv("LIVE_POLL_SEC", "0.2"))
    run_live(in_file, poll)
